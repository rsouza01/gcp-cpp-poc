# Notes

## References

* https://github.com/googleapis/google-cloud-cpp/tree/b7056e80092636d9bd0296e319b05b0e552d56d6/google/cloud/secretmanager/quickstart
