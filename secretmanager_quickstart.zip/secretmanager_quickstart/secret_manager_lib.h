// secret_manager_lib.h
#ifndef SECRET_MANAGER_LIB_H
#define SECRET_MANAGER_LIB_H

char* get_secret(char* secret, int version);

#endif
